using UnityEngine;

public class Ssilka : MonoBehaviour
{
	public void OpenURL(string url)
	{
		Application.OpenURL(url);
	}
}