using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class SpeedGameManager : MonoBehaviour
{
	[SerializeField] private TextMeshProUGUI _timerText;
    [SerializeField] private TextMeshProUGUI _scoreText;
    [SerializeField] private TextMeshProUGUI[] _variantTexts;
	[SerializeField] private Image[] _buttonImages;
	[SerializeField] private Image _image;
    

    [SerializeField] private GameObject _buttonNext;
    [SerializeField] private float _secondForQuestion = 30f;
    [SerializeField] private float _currentTime = 30f;

    [Serializable]
    public struct SpeedTest
    {
        public Sprite sprite;
        public string[] texts;
        public int rightIndex;
    }

    [SerializeField]
    SpeedTest[] tests;

    private int _index = 0;
    private int _score = 0;
    private bool _needTimer = true;

	public void Update()
	{
        if (!_needTimer)
            return;

        _currentTime -= Time.deltaTime;
        _timerText.text = Mathf.Round(_currentTime).ToString();

        if (_currentTime <= 0.5f)
            TimeExpired();
    }


	public void ChangeTest()
	{
        _currentTime = _secondForQuestion;
        _needTimer = true;

        _index = UnityEngine.Random.Range(0, tests.Length);
        
        _buttonNext.SetActive(false);

        int i = 0;
        foreach(TextMeshProUGUI variantText in _variantTexts)
		{
            variantText.text = tests[_index].texts[i];
            i++;
        }

        _image.sprite = tests[_index].sprite;

        foreach(Image img in _buttonImages)
		{
            img.color = Color.white;
        }
    }

    public void GiveAnswer(int answerIndex)
	{
        _buttonNext.SetActive(true);
        _needTimer = false;

        if (answerIndex == tests[_index].rightIndex)
        {
            
            _buttonImages[answerIndex].color = Color.green;
            _score++;
            _scoreText.text = _score.ToString();
            
        }
		else
        {
            
            _buttonImages[answerIndex].color = Color.red;
            _buttonImages[tests[_index].rightIndex].color = Color.green;
            
        }
    }

    
    
       
    private void TimeExpired()
    {
        _buttonNext.SetActive(true);
        _needTimer = false;

        _buttonImages[tests[_index].rightIndex].color = Color.green;
    }
}