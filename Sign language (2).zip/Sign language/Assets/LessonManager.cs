using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class LessonManager : MonoBehaviour
{
	[SerializeField] private TextMeshProUGUI _header;
	[SerializeField] private TextMeshProUGUI _text;
	[SerializeField] private Image _image;
    [SerializeField] private GameObject _buttonPlay;
    [SerializeField] private GameObject _buttonPlay2;
    [SerializeField] private GameObject _buttonPlay3;
    [SerializeField] private GameObject _buttonPlay4;
    [SerializeField] private GameObject _buttonPlay5;
    [SerializeField] private GameObject _buttonKurs;
    [SerializeField] private GameObject _buttonNext;
    [SerializeField] private GameObject _buttonPrevios;
    private int _index = 0;
    

    [Serializable]
    public struct Lesson
    {
        public string text;
        public Sprite sprite;
    }

    [SerializeField]
    Lesson[] lessons;

    public void ChangeLessonIndex(int index)
    {
        ChangeLesson(index-_index);
    }

    public void ChangeLesson(int indexDelta)
	{
        _index += indexDelta;
        
        if (_index == 1)
            _buttonPlay.SetActive(true);
        else
            _buttonPlay.SetActive(false);

        if (_index == 6)
            _buttonPlay2.SetActive(true);
        else
            _buttonPlay2.SetActive(false);
        if (_index == 12)
            _buttonPlay3.SetActive(true);
        else
            _buttonPlay3.SetActive(false);
            
        if (_index == 32)
            _buttonPlay4.SetActive(true);
        else
            _buttonPlay4.SetActive(false);
        if (_index == 31)
            _buttonPlay5.SetActive(true);
        else
            _buttonPlay5.SetActive(false);
        if (_index == 0)  
            _buttonKurs.SetActive(true);
        else
            _buttonKurs.SetActive(false);

        if (_index == 0)
            _buttonPrevios.SetActive(false);
        else
            _buttonPrevios.SetActive(true);

        if (_index == lessons.Length - 1)
            _buttonNext.SetActive(false);
        else
            _buttonNext.SetActive(true);

        _text.text = lessons[_index].text;
        _image.sprite = lessons[_index].sprite;

        _header.text = "���� " + (_index+1).ToString();
    }
    
}